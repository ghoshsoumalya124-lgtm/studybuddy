---
name: StudyMate
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464555'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4c42e9'
  primary: '#493ee5'
  on-primary: '#ffffff'
  primary-container: '#635bff'
  on-primary-container: '#fefaff'
  inverse-primary: '#c3c0ff'
  secondary: '#006591'
  on-secondary: '#ffffff'
  secondary-container: '#39b8fd'
  on-secondary-container: '#004666'
  tertiary: '#6a37d3'
  on-tertiary: '#ffffff'
  tertiary-container: '#8354ee'
  on-tertiary-container: '#fffafd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#321ed2'
  secondary-fixed: '#c9e6ff'
  secondary-fixed-dim: '#89ceff'
  on-secondary-fixed: '#001e2f'
  on-secondary-fixed-variant: '#004c6e'
  tertiary-fixed: '#e9ddff'
  tertiary-fixed-dim: '#d0bcff'
  on-tertiary-fixed: '#23005c'
  on-tertiary-fixed-variant: '#5516be'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 44px
    fontWeight: '700'
    lineHeight: 52px
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

### Personality & Emotional Response
The design system embodies calm clarity, quiet encouragement, and structured focus. Aimed at high school, university, and independent learners juggling complex academic loads, the interface reduces cognitive overhead rather than adding sensory stimulation. The visual tone feels like a clean desk at the start of a productive study session: ordered, intentional, and empowering.

### Design Movement
**Refined SaaS Minimalism with Soft Humanist Utility.** 
A synthesis of clean structural grids, generous white space, soft neutral backgrounds, and deliberate color accents. Contrast is tuned for sustained readability over multi-hour study sessions. Elevation relies on subtle, diffuse ambient lighting and precise single-pixel borders rather than aggressive skeuomorphism or harsh stark lines.

## Colors

### Palette System
- **Primary (`#635BFF` - Electric Indigo):** Anchors primary actions, focus states, active session indicators, and key navigational milestones. Conveys intellectual momentum without feeling corporate or clinical.
- **Secondary (`#0EA5E9` - Sky Blue):** Applied to progress metrics, study timers, analytical data streams, and informational highlights.
- **Tertiary (`#8B5CF6` - Soft Lavender):** Powers contextual tags, subject taxonomy, flashcard categorization, and supportive milestones.
- **Neutral Base (`#0F172A` - Slate Charcoal):** Primary text and structural contrast points.

### Background & Surface Hierarchy
- **Canvas Base (`#F8FAFC`):** The foundational app backdrop. Reduces screen glare over extended sessions.
- **Surface Elevation 0 (`#FFFFFF`):** High-priority study cards, modal sheets, and active focus panels.
- **Subtle Stroke (`#E2E8F0`):** Single-pixel perimeter borders separating floating card elements from the soft off-white canvas.
- **Muted Typography (`#64748B`):** Supporting metadata, timestamps, and secondary card descriptions.

## Typography

### Structural Approach
The typography utilizes **Inter** across all visual layers to ensure consistent geometric rhythm, high x-height clarity, and legible numeric tracking for study timers, grade metrics, and deadline countdowns.

### Hierarchical Hierarchy
- **Displays & Headlines:** Set in weights `600` and `700` with tight negative letter spacing (`-0.02em` to `-0.01em`) to create clean, focused titles without visual clutter.
- **Body Text:** Standardized on `14px` and `16px` with comfortable line-heights (`1.5` to `1.6`) to prevent eye fatigue during lengthy reading and note-taking sessions.
- **Labels & Microcopy:** Weighted at `500` and `600`, tracking slightly wide (`+0.01em`) when set in uppercase or micro sizes (`11px` to `12px`) for status tags and category chips.

## Layout & Spacing

### Grid & Layout Philosophy
The architecture uses a 12-column fluid grid on desktop (`>1024px`) with a maximum content container width of `1280px`. On tablet (`768px - 1023px`), the grid collapses to 8 columns with unified `1.5rem` gutters. On mobile (`<768px`), layout reflows into a single 4-column stack with `1rem` margins to maximize lateral canvas real estate.

### Spacing Principles
- Layout structures follow an 8pt base grid with a 4pt sub-grid for internal component padding.
- Cards maintain distinct internal breathing room (`space-md` to `space-lg`), separating task items cleanly without excessive dividing lines.
- Module groups (e.g., Focus Timer next to Task Checklist) strictly align horizontally with `gutter` tokens to ensure structured visual balance.

## Elevation & Depth

### Atmospheric Depth
Visual hierarchy is established through a hybrid system of crisp 1px borders and soft, diffused ambient light. Deep drop shadows are avoided to keep the interface feeling weightless and modern.

### Elevation Scales
- **Surface Flat (Level 0):** Canvas `#F8FAFC`. Background containers and inactive sections have no elevation.
- **Surface Rest (Level 1):** `#FFFFFF` surfaces sit on a subtle border (`1px solid #E2E8F0`) paired with an ultra-light ambient shadow: `box-shadow: 0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.02)`. Used for task cards, assignment items, and study logs.
- **Surface Floating (Level 2):** Applied to active panels, focused timers, dropdown menus, and hover states on cards: `box-shadow: 0 4px 12px -2px rgba(15, 23, 42, 0.06), 0 2px 6px -2px rgba(15, 23, 42, 0.03)`.
- **Surface Overlay (Level 3):** Modal study prompts, focus mode overlays, and flashcard stacks: `box-shadow: 0 20px 25px -5px rgba(15, 23, 42, 0.08), 0 8px 10px -6px rgba(15, 23, 42, 0.04)`.

## Shapes

### Form Geometry
The shape language uses `roundedness: 2`, delivering balanced rounded geometry (`0.5rem` base, `1rem` for medium cards, `1.5rem` for large contextual sheets). 

This curvature softens the data-heavy nature of study schedules without drifting into whimsical or overly playful forms. Status indicators, interactive filter chips, and pill buttons scale up to continuous smooth capsules (`9999px`) to create clear differentiation between actionable items and structural content blocks.

## Components

### Buttons
- **Primary:** Filled `#635BFF` with white text. Height: `42px` (desktop), `44px` (mobile touch target). Border radius: `0.5rem`. Smooth hover transition shifting to `#5046E5`.
- **Secondary / Subdued:** Background tint `#635BFF` at 8% opacity with `#635BFF` text. Zero border. Hover state darkens tint to 14%.
- **Tertiary / Outline:** `#FFFFFF` background with `1px solid #E2E8F0` border and `#0F172A` text. Hover adds subtle border darken to `#CBD5E1`.

### Cards & Module Panels
- Set with `#FFFFFF` background, `1px solid #E2E8F0`, and `1rem` corner rounding.
- Internal padding stays strictly at `space-md` or `space-lg`.
- Focus cards (e.g., active Pomodoro timer) feature a `2px` left border highlight tinted with `#635BFF` or `#0EA5E9`.

### Chips & Status Tags
- Height: `24px` to `28px`. Pill radius (`9999px`). Internal padding: `space-xs` horizontal, `space-sm` vertical.
- **In-Progress Tag:** Sky blue fill (`#E0F2FE`), Sky blue text (`#0369A1`).
- **Subject Tag:** Soft lavender fill (`#F3E8FF`), Lavender text (`#6D28D9`).
- **Completed Tag:** Mint green fill (`#ECFDF5`), Mint text (`#047857`).

### Input Fields
- Solid `#FFFFFF` fill with `1px solid #CBD5E1` resting border, rounded to `0.5rem`.
- Padding: `0.625rem 0.875rem`. Text: `body-md`.
- Focus state eliminates the native browser ring, applying a clean dual-ring: `0 0 0 3px rgba(99, 91, 255, 0.15)` and border color `#635BFF`.

### Checkboxes & Radio Controls
- Checkboxes: `18px × 18px` squares with `4px` corner radii. Unchecked state uses a crisp `1.5px solid #CBD5E1` outline on white. Checked state transitions to solid `#635BFF` fill with a white centered icon.
- Radios: Circular with identical interaction tokens and an inner dot transition.

### Specialized Study Components
- **Streak & Goal Counters:** Pill-shaped `#FFFFFF` badge with a miniature flame/target icon in `#635BFF`, bordered with `#E2E8F0`, displaying bold micro-counts.
- **Progress Trackers:** Slim line meters (`6px` height) with `#F1F5F9` track fill and continuous gradient progress indicators shifting smoothly from `#635BFF` to `#0EA5E9`.